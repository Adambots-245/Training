package solutions.ex01;

// Battery.java: the blueprint. Every Battery object gets its own name, year and voltage.
public class Battery {
    String name;
    int year;
    double voltage;

    boolean isMatchReady() {
        return voltage >= 12.0;
    }

    void describe() {
        System.out.println(name + " (" + year + "): " + voltage + " V");
    }

    // stretch
    int age(int thisYear) {
        return thisYear - year;
    }
}

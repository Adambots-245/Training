package solutions.ex01;

public class Main {
    public static void main(String[] args) {
        Battery a = new Battery();
        a.name = "2025-A";
        a.year = 2025;
        a.voltage = 12.8;

        Battery b = new Battery();
        b.name = "2024-B";
        b.year = 2024;
        b.voltage = 11.8;

        Battery c = new Battery();
        c.name = "2023-C";
        c.year = 2023;
        c.voltage = 12.6;

        a.describe();
        System.out.println("  match-ready: " + a.isMatchReady());
        b.describe();
        System.out.println("  match-ready: " + b.isMatchReady());
        c.describe();
        System.out.println("  match-ready: " + c.isMatchReady());

        // stretch
        System.out.println(c.name + " is " + c.age(2026) + " years old");
    }
}

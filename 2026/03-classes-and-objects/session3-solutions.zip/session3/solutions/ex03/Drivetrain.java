package solutions.ex03;

public class Drivetrain {
    private Motor leftMotor = new Motor("left");
    private Motor rightMotor = new Motor("right");   // FIX 1: build it with new;
    private Battery battery;

    public void setup() {
        battery = new Battery("2025-A", 12.8);   // FIX 2: no "Battery" in front, so it fills in the FIELD
        System.out.println("Setup done.");
    }

    public void drive(double speed) {
        leftMotor.setThrottle(speed);
        rightMotor.setThrottle(speed);
    }

    public void checkBattery() {
        if (battery.isMatchReady()) {
            System.out.println("All systems go");
        } else {
            System.out.println("Charge the battery first");
        }
    }
}

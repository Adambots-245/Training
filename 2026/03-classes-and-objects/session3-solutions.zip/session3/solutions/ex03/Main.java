package solutions.ex03;

public class Main {
    public static void main(String[] args) {
        Drivetrain drive = new Drivetrain();
        drive.setup();
        drive.drive(0.5);
        drive.checkBattery();
    }
}

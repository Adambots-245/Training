package solutions.ex03;

// A pretend motor for practice. It prints instead of spinning.
public class Motor {
    private final String name;

    public Motor(String name) {
        this.name = name;
    }

    public void setThrottle(double throttle) {
        System.out.println("  " + name + " motor set to " + throttle);
    }
}

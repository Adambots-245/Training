package solutions.ex04;

public class SwerveModule {
    private final String name;
    private double angle;

    public SwerveModule(String name) {
        this.name = name;
    }

    public void setAngle(double degrees) {
        angle = degrees;
    }

    public double getAngle() {
        return angle;
    }

    public void drive(double speed) {
        System.out.println(name + " is driving at " + speed);
    }
}

package solutions.ex04;

public class Main {
    public static void main(String[] args) {
        SwerveModule fl = new SwerveModule("FL");
        SwerveModule fr = new SwerveModule("FR");

        fl.setAngle(45);
        fr.setAngle(90);

        System.out.println("FL angle: " + fl.getAngle());
        System.out.println("FR angle: " + fr.getAngle());

        fl.drive(0.5);

        // ---- CHECK: don't change anything below this line ----
        SwerveModule t1 = new SwerveModule("T1");
        SwerveModule t2 = new SwerveModule("T2");
        t1.setAngle(10);
        t2.setAngle(20);
        if (t1.getAngle() == t2.getAngle()) {
            System.out.println("WARNING: the modules are sharing ONE angle. Did you add static? Take it out!");
        } else {
            System.out.println("CHECK PASSED: each module has its own angle");
        }
    }
}

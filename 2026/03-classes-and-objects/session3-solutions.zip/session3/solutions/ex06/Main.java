package solutions.ex06;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        ArrayList<Battery> cart = new ArrayList<>();
        cart.add(new Battery("2025-A", 12.8));
        cart.add(new Battery("2025-B", 11.8));
        cart.add(new Battery("2024-A", 12.7));
        cart.add(new Battery("2024-B", 11.9));
        cart.add(new Battery("2023-A", 12.5));

        int ready = 0;
        for (Battery b : cart) {
            String status = b.isMatchReady() ? "ready" : "charge me";
            System.out.println(b.getName() + "  " + b.getVoltage() + " V  " + status);
            if (b.isMatchReady()) {
                ready++;
            }
        }
        System.out.println(ready + " of " + cart.size() + " batteries are match-ready");

        // stretch: keep the best one so far
        Battery best = cart.get(0);
        for (Battery b : cart) {
            if (b.getVoltage() > best.getVoltage()) {
                best = b;
            }
        }
        System.out.println("Highest: " + best.getName() + " (" + best.getVoltage() + " V)");
    }
}

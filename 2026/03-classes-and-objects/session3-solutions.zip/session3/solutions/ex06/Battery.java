package solutions.ex06;

public class Battery {
    private final String name;
    private final double voltage;

    public Battery(String name, double voltage) {
        this.name = name;
        this.voltage = voltage;
    }

    public String getName() {
        return name;
    }

    public double getVoltage() {
        return voltage;
    }

    public boolean isMatchReady() {
        return voltage >= 12.0;
    }
}

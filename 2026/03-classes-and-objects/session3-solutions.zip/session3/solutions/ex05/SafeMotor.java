package solutions.ex05;

public class SafeMotor {
    private double speed;

    public void setSpeed(double speed) {
        this.speed = Math.clamp(speed, -1.0, 1.0);
        // Same thing with if / else:
        // if (speed > 1.0) { this.speed = 1.0; }
        // else if (speed < -1.0) { this.speed = -1.0; }
        // else { this.speed = speed; }
    }

    public double getSpeed() {
        return speed;
    }
}

package solutions.ex05;

public class Main {
    public static void main(String[] args) {
        SafeMotor motor = new SafeMotor();

        check(motor, 0.5, 0.5);
        check(motor, 3.0, 1.0);
        check(motor, -7.0, -1.0);
        check(motor, -0.25, -0.25);
    }

    // A helper that needs no object's data, so it's fine for it to be static.
    static void check(SafeMotor motor, double input, double expected) {
        motor.setSpeed(input);
        double got = motor.getSpeed();
        String result = (got == expected) ? "PASS" : "FAIL (expected " + expected + ")";
        System.out.println("setSpeed(" + input + ") -> " + got + "   " + result);
    }
}

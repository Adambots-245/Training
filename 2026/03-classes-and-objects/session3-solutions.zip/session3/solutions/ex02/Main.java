package solutions.ex02;

public class Main {
    public static void main(String[] args) {
        Battery a = new Battery("2025-A", 2025, 12.8);
        Battery b = new Battery("2024-B", 2024, 12.3);
        Battery c = new Battery("2023-C", 2023, 12.6);
        Battery d = new Battery("2022-D", 2022, 11.9);

        a.describe();
        b.describe();
        c.describe();
        d.describe();

        Battery spare = new Battery("Spare");
        spare.describe();
    }
}

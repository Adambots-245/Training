package solutions.ex02;

public class Battery {
    String name;
    int year;
    double voltage;

    public Battery(String name, int year, double voltage) {
        this.name = name;
        this.year = year;
        this.voltage = voltage;   // FIX: "this." means the field
    }

    // stretch: a second constructor (this is called "overloading")
    public Battery(String name) {
        this.name = name;
        this.year = 2026;
        this.voltage = 12.0;
    }

    boolean isMatchReady() {
        return voltage >= 12.0;
    }

    void describe() {
        System.out.println(name + ": " + voltage + " V  ready: " + isMatchReady());
    }
}

# Session 3 solutions: Classes and Objects

One finished version of each exercise, with the fixes commented.

## How to use them
1. Unzip into `C:\bootcamp`. The files land in `C:\bootcamp\session3\solutions`, next to your own `ex01` to `ex07`.
2. Open `C:\bootcamp\session3` in WPILib VS Code (the same folder as your exercises).
3. Open a solution's `Main.java` and click **Run**.

Each solution's first line says `package solutions.ex01;` (and so on), so the solutions and your own work can sit side by side without clashing.

Try the exercise yourself first. Compare with the solution afterwards: there is often more than one right answer.

## Notes on the tricky ones
- **ex03 (null hunt):** the first crash is `rightMotor`, which was never built with `new`. Once that's fixed, the second crash is `battery`: `setup()` says `Battery battery = new Battery(...)`, which makes a brand-new local variable that disappears at the closing brace, so the field stays null. The fix is `battery = new Battery(...)`, with no type in front.
- **ex04 (static context):** the starter doesn't compile on purpose (three errors). Adding `static` to SwerveModule makes it compile, but the check prints a WARNING, because every module would then share one angle. The right fix is to make objects.
- **ex05 (SafeMotor):** making `speed` private breaks one line in Main.java on purpose ("speed has private access in SafeMotor"). Delete that line: other classes should go through `setSpeed()` and `getSpeed()`.
- **ex07 (subsystem):** going further, add a second `Intake` on channels 2 and 3 in a copy of Main and show that both objects work on their own.

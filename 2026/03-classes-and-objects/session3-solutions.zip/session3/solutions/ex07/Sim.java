package solutions.ex07;

// The match simulator's clock. Don't change this file.
public class Sim {
    static int loop = 0;
    static final int PIECE_ARRIVES_AT = 20;
}

package solutions.ex07;

// A FAKE beam-break sensor. Don't change this file.
// Like the real one, get() is TRUE when the beam is clear (no game piece)
// and FALSE when something is blocking it (a game piece is inside).
public class BeamBreak {
    public BeamBreak(int channel) {
    }

    public boolean get() {
        return Sim.loop < Sim.PIECE_ARRIVES_AT;
    }
}

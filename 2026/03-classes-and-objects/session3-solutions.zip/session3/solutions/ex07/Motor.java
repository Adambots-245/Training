package solutions.ex07;

import java.util.HashMap;

// A FAKE motor for practice, so this runs without a robot. Don't change this file.
public class Motor {
    private static final HashMap<Integer, Motor> BY_CHANNEL = new HashMap<>();
    private double throttle = 0.0;

    public Motor(int channel) {
        BY_CHANNEL.put(channel, this);
    }

    public void setThrottle(double throttle) {
        this.throttle = Math.clamp(throttle, -1.0, 1.0);
    }

    public double getThrottle() {
        return throttle;
    }

    // Used by the simulator to peek at the motor on a channel.
    static Motor onChannel(int channel) {
        return BY_CHANNEL.get(channel);
    }
}

package solutions.ex07;

public class Intake {
    private static final double kIntakeSpeed = 0.75;
    private final Motor motor;
    private final BeamBreak beamBreak;

    public Intake(int motorChannel, int sensorChannel) {
        motor = new Motor(motorChannel);
        beamBreak = new BeamBreak(sensorChannel);
    }

    public void run() {
        if (hasGamePiece()) {
            stop();
        } else {
            motor.setThrottle(kIntakeSpeed);
        }
    }

    public void stop() {
        motor.setThrottle(0.0);
    }

    public boolean hasGamePiece() {
        return !beamBreak.get();   // beam blocked = piece inside
    }
}

package ex07;

// Runs a 50-loop simulated match (one loop = 20 ms on a real robot) and checks your Intake.
// Don't change this file. Just run it.
public class Main {
    public static void main(String[] args) {
        Intake intake = new Intake(0, 1);

        boolean runsBefore = true;
        boolean stopsAfter = true;
        boolean motorBuilt = Motor.onChannel(0) != null;

        for (int loop = 0; loop < 50; loop++) {
            Sim.loop = loop;
            intake.run();
            double throttle = motorBuilt ? Motor.onChannel(0).getThrottle() : 0.0;
            boolean piece = intake.hasGamePiece();
            if (loop % 10 == 0 || loop == Sim.PIECE_ARRIVES_AT - 1) {
                System.out.printf("loop %2d: motor %-4s  piece: %s%n", loop, throttle, piece);
            }
            if (loop < Sim.PIECE_ARRIVES_AT && throttle != 0.75) {
                runsBefore = false;
            }
            if (loop >= Sim.PIECE_ARRIVES_AT && throttle != 0.0) {
                stopsAfter = false;
            }
        }

        int passed = 0;
        passed += report(runsBefore, "motor runs before the piece");
        passed += report(stopsAfter, "motor stops when the piece arrives");
        passed += report(intake.hasGamePiece(), "hasGamePiece() is true at the end");
        if (!motorBuilt) {
            System.out.println("HINT: no Motor was built on channel 0. Does your constructor say new Motor(motorChannel)?");
        }
        System.out.println(passed + " / 3 checks passed");
    }

    static int report(boolean ok, String what) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
        return ok ? 1 : 0;
    }
}

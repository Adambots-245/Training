package ex07;

// Exercise 7: build the Intake subsystem from scratch.
// Use the fake robot parts in this folder: Motor and BeamBreak.
// Then run Main.java. It simulates a match and checks your work.
public class Intake {
    // TODO 1: two PRIVATE fields: a Motor called motor, and a BeamBreak called beamBreak.

    // TODO 2: build both parts with new, using the channel numbers handed in.
    public Intake(int motorChannel, int sensorChannel) {
    }

    // TODO 3: if there's a game piece, stop. Otherwise spin the motor at 0.75.
    public void run() {
    }

    // TODO 4: set the motor's throttle to 0.0.
    public void stop() {
    }

    // TODO 5: the beam is BLOCKED when a piece is inside, so return !beamBreak.get()
    public boolean hasGamePiece() {
        return false;
    }
}

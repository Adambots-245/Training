package ex03;

public class Drivetrain {
    private Motor leftMotor = new Motor("left");
    private Motor rightMotor;
    private Battery battery;

    public void setup() {
        Battery battery = new Battery("2025-A", 12.8);
        System.out.println("Setup done.");
    }

    public void drive(double speed) {
        leftMotor.setThrottle(speed);
        rightMotor.setThrottle(speed);
    }

    public void checkBattery() {
        if (battery.isMatchReady()) {
            System.out.println("All systems go");
        } else {
            System.out.println("Charge the battery first");
        }
    }
}

package ex03;

// Exercise 3: null hunt.
// Run it. Read the NullPointerException: WHICH variable is null, in WHICH file and line?
// Fix it, run again, and hunt down the second one.
public class Main {
    public static void main(String[] args) {
        Drivetrain drive = new Drivetrain();
        drive.setup();
        drive.drive(0.5);
        drive.checkBattery();
    }
}

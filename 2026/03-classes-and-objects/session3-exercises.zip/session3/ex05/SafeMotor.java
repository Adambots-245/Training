package ex05;

public class SafeMotor {
    // TODO 1: make this field private
    public double speed;

    public void setSpeed(double speed) {
        // TODO 3: clamp it, so speed always stays between -1.0 and 1.0.
        //         Hint: Math.clamp(value, low, high) does exactly this.
        this.speed = speed;
    }

    public double getSpeed() {
        return speed;
    }
}

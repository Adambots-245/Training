package ex01;

// Battery.java: the blueprint. Every Battery object gets its own name, year and voltage.
public class Battery {
    String name;
    int year;
    double voltage;

    boolean isMatchReady() {
        return voltage >= 12.0;
    }

    // TODO 1: add a method called describe() that prints this battery's
    //         name, year and voltage on one line, like this:
    //         2025-A (2025): 12.8 V
}

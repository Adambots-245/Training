package ex01;

// Exercise 1: your first class.  Run this file with the Run link above main.
public class Main {
    public static void main(String[] args) {
        // One battery is built for you:
        Battery a = new Battery();
        a.name = "2025-A";
        a.year = 2025;
        a.voltage = 12.8;

        // TODO 2: build two more batteries with new, and fill in their fields:
        //         b is "2024-B", 2024, 11.8
        //         c is "2023-C", 2023, 12.6

        // TODO 3: for each battery, call describe(), then print isMatchReady().
        //         Battery a's match-ready line is done for you:
        System.out.println("  match-ready: " + a.isMatchReady());

        // STRETCH: add a method int age(int thisYear) to Battery and print each battery's age.
    }
}

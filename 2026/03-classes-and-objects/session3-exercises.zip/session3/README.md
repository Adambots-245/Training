# Session 3 exercise pack: Classes and Objects

Plain Java. No robot or WPILib needed. The robot parts (motors, sensors) are small fake classes that print what they're doing.

## How to run
1. Unzip the pack into `C:\bootcamp`, so you get `C:\bootcamp\session3`. (Not in Documents, Desktop or OneDrive.)
2. In WPILib 2027 VS Code, use **File > Open Folder** and open the whole `C:\bootcamp\session3` folder (not a single exercise folder).
3. Open the exercise's `Main.java` and click the grey **Run** link above `main`.
4. Each exercise is its own folder (a *package*). The first line of every file says `package ex01;` (or ex02, ...). Leave that line alone; section 7 of the deck explains it.

## The exercises
| Folder | Deck slide | What you practice |
|---|---|---|
| `ex01` | Try it: your first class | Fields, a method, building three objects with `new` |
| `ex02` | Try it: add a constructor | Fix the `voltage = voltage;` bug, build objects in one line, stretch: a second constructor |
| `ex03` | Try it: null hunt | Read two NullPointerExceptions and fix them (a missing `new`, and a local variable hiding a field) |
| `ex04` | Try it: fix it the right way | Fix three "static context" errors by making objects. A built-in check warns if you cheat with `static` |
| `ex05` | Try it: build a SafeMotor | `private` field, a clamping setter, a getter. PASS/FAIL checks |
| `ex06` | Try it: the battery cart | `ArrayList<Battery>`, a for-each loop, counting, stretch: find the highest voltage |
| `ex07` | Try it: build a subsystem | Write an `Intake` class from scratch against fake hardware. A 50-loop simulated match checks it |

`CheatSheet2.pdf` is a one-page reference for this deck.

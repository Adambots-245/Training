package ex04;

// Exercise 4: fix it the right way.
// The three lines marked ERROR won't compile: "non-static method ... cannot be
// referenced from a static context." Java is asking: WHICH module?
// Fix each one by making a SwerveModule object and calling the method ON it.
// Do NOT add the word static to SwerveModule.java.
public class Main {
    public static void main(String[] args) {
        // TODO: make two modules here:  fl named "FL"  and  fr named "FR"

        SwerveModule.setAngle(45);                                    // ERROR 1: set fl's angle to 45
        // TODO: set fr's angle to 90

        System.out.println("FL angle: " + SwerveModule.getAngle());   // ERROR 2: print fl's angle
        // TODO: print fr's angle the same way ("FR angle: ...")

        SwerveModule.drive(0.5);                                      // ERROR 3: make fl drive at 0.5

        // ---- CHECK: don't change anything below this line ----
        SwerveModule t1 = new SwerveModule("T1");
        SwerveModule t2 = new SwerveModule("T2");
        t1.setAngle(10);
        t2.setAngle(20);
        if (t1.getAngle() == t2.getAngle()) {
            System.out.println("WARNING: the modules are sharing ONE angle. Did you add static? Take it out!");
        } else {
            System.out.println("CHECK PASSED: each module has its own angle");
        }
    }
}

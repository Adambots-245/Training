package ex02;

// Exercise 2: constructors.
// Run it first. Every battery says 0.0 V. Find the bug in Battery's constructor!
public class Main {
    public static void main(String[] args) {
        Battery a = new Battery("2025-A", 2025, 12.8);
        Battery b = new Battery("2024-B", 2024, 12.3);
        Battery c = new Battery("2023-C", 2023, 12.6);

        a.describe();
        b.describe();
        c.describe();

        // TODO: add a fourth battery, "2022-D", 2022, 11.9, in ONE line, and describe it.

        // STRETCH: once you've added the name-only constructor, try:
        // Battery spare = new Battery("Spare");
        // spare.describe();
    }
}

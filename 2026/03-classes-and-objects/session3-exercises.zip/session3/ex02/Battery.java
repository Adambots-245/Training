package ex02;

public class Battery {
    String name;
    int year;
    double voltage;

    public Battery(String name, int year, double voltage) {
        this.name = name;
        this.year = year;
        voltage = voltage;
    }

    // STRETCH: add a second constructor that takes only a name.
    //          It should set year to 2026 and voltage to 12.0.

    boolean isMatchReady() {
        return voltage >= 12.0;
    }

    void describe() {
        System.out.println(name + ": " + voltage + " V  ready: " + isMatchReady());
    }
}

package ex06;

import java.util.ArrayList;

// Exercise 6: the battery cart.
public class Main {
    public static void main(String[] args) {
        // TODO 1: make an ArrayList<Battery> called cart.

        // TODO 2: add these five batteries to the cart:
        //   "2025-A" 12.8    "2025-B" 11.8    "2024-A" 12.7    "2024-B" 11.9    "2023-A" 12.5

        // TODO 3: loop over the cart and print each battery, like:
        //   2025-A  12.8 V  ready
        //   2025-B  11.8 V  charge me

        // TODO 4: count how many are match-ready and print:
        //   3 of 5 batteries are match-ready

        // STRETCH: find the battery with the highest voltage and print:
        //   Highest: 2025-A (12.8 V)
    }
}

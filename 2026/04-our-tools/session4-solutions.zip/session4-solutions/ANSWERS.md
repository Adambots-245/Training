# Session 4 scavenger hunt: answers

This folder is the scavenger-hunt project with every task done. Open it in WPILib VS Code (File, Open Folder) and the Problems panel is empty.

1. **The file where the Intake object is created:** `Robot.java` (`public final Intake intake = new Intake();`).
2. **WPILib's own PWMSparkMax class:** click on `PWMSparkMax` and press **F12** (Go to Definition). VS Code opens WPILib's code, read-only.
3. **The missing import in Shooter.java:** `DigitalInput`. Click the red word, then the light bulb, then **Import 'DigitalInput'**. It adds `import org.wpilib.hardware.discrete.DigitalInput;`.
4. **Rename kIntakeSpeed to kIntakeThrottle with F2:** one rename updates `Constants.java`, `subsystems/Intake.java` and `Messy.java`.
5. **Which file calls stop()?** **Ctrl+Shift+F** (Mac: **Cmd+Shift+F**) finds 4 matches: 2 are where `stop()` is written (`Intake.java` and `Shooter.java`), and the 2 calls are in `Robot.java`, where they become default commands. Answer: `Robot.java`.
6. **Format Messy.java:** **Shift+Alt+F** (Mac: **Shift+Option+F**).
7. **The one remaining error:** the typo `kShooterSped` in `subsystems/Shooter.java`. It should be `kShooterSpeed`.
8. **"Deploy Robot Code":** in the WPILib menu (the WPILib logo in the top-right corner). Found, not run.

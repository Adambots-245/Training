package first.robot;

/** A messy file for the scavenger hunt. Format it: Shift+Alt+F (Mac: Shift+Option+F). */
public class Messy {
public static double limit(double speed){
        if(speed>1.0){
    return 1.0;}
            else if (speed<-1.0) {return -1.0;}
  return speed;
      }

    public static boolean isFast(double speed)
  {
return Math.abs(speed)>Constants.kIntakeSpeed;
        }
}

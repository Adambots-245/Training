public class Ex01_Hello {
    public static void main(String[] args) {
        System.out.println("Hello, Ava!");
        System.out.println("I'm in 9th grade.");
        System.out.println("My favorite robot part is the shooter.");
    }
}

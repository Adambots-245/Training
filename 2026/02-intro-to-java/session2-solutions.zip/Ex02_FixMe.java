// The five fixes:
//   1. class name Ex02_Fixme -> Ex02_FixMe (must match the file name)
//   2. int team = 245   -> added ;
//   3. string -> String
//   4. system -> System
//   5. curly quotes -> straight quotes
//   (and the class's closing } was missing at the end)

public class Ex02_FixMe {
    public static void main(String[] args) {
        int team = 245;
        String name = "AdamBots";
        System.out.println("Team " + team);
        System.out.println(name);
        System.out.println("Fixed it!");
    }
}

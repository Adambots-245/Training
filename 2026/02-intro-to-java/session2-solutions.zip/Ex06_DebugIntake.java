// Ex06 solution, with each fix marked.

public class Ex06_DebugIntake {

    // ----- pretend robot hardware (no WPILib needed; don't change this part) -----
    static class Motor {
        double throttle;
        void setThrottle(double t) { throttle = t; }
    }
    static class BeamBreak {
        int time;
        // true = beam NOT blocked. A game piece arrives at loop 5 and blocks it.
        boolean get() { return time < 5; }
    }
    static final Motor motor = new Motor();
    static final BeamBreak beamBreak = new BeamBreak();
    static int loopsRunning = 0;

    // FIX 2 (types): 0.75 doesn't fit in an int box. Use double.
    static final double kIntakeSpeed = 0.75;

    static boolean hasGamePiece() {
        boolean blocked = !beamBreak.get();
        // FIX 6 (methods): a boolean method must return a value.
        return blocked;
    }

    static void run() {
        // FIX 4 (comparisons): = stores, == compares. Even simpler: if (hasGamePiece())
        if (hasGamePiece()) {
            motor.setThrottle(0.0);
        } else {
            double speed = kIntakeSpeed;
            if (loopsRunning < 2) {
                // FIX 3 (operators): 1 / 2 is integer division = 0. Use 0.5 (or 1.0 / 2).
                speed = kIntakeSpeed * 0.5;
            }
            motor.setThrottle(speed);
            loopsRunning++;
        }
    }

    static void periodic() {
        // FIX 5 (loops): never wait in a loop inside robot code. The robot loop
        // already calls periodic() every 20 ms, so just run() once and return.
        run();
    } // FIX 1 (structure): periodic() was missing its closing brace.

    // ----- the robot loop: calls periodic() 8 times, like 8 x 20 ms -----
    public static void main(String[] args) {
        for (int loop = 0; loop < 8; loop++) {
            beamBreak.time = loop;
            periodic();
            System.out.println("Loop " + loop + ": hasGamePiece=" + hasGamePiece() + "  motor=" + motor.throttle);
        }
    }
}

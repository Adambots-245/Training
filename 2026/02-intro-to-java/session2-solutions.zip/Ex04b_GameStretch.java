public class Ex04b_GameStretch {

    static void autonomous() {
        forward();
        turnLeft();
        for (int i = 0; i < 3; i++) {
            forward();
        }
        turnRight();
        for (int i = 0; i < 3; i++) {
            forward();
            if (onBall()) {
                pickUp();
            }
        }
        forward();
        turnRight();
        for (int i = 0; i < 2; i++) {
            forward();
        }
        turnLeft();
        while (pathClear()) {
            forward();
        }
        turnLeft();
        while (pathClear()) {
            forward();
        }
        score();
    }

    // ===================================================================
    // The game field from our first session (you don't need to change anything below)
    //   9 x 5 grid, robot starts bottom-left facing right, goal top-right.
    //   The ball is in one of two spots; main() tries BOTH.
    // ===================================================================
    static final int COLS = 9, ROWS = 5;
    static final int[][] WALLS = {{2,2},{2,3},{2,4},{6,0},{6,1},{6,2},{3,0},{4,3}};
    static final int[][] SPOTS = {{3,1},{4,1}};
    static int x, y, dir, ballX, ballY, moves;
    static boolean hasBall, scored;

    static boolean isWall(int cx, int cy) {
        if (cx < 0 || cy < 0 || cx >= COLS || cy >= ROWS) return true;
        for (int[] w : WALLS) if (w[0] == cx && w[1] == cy) return true;
        return false;
    }
    static int aheadX() { return x + new int[]{1, 0, -1, 0}[dir]; }
    static int aheadY() { return y + new int[]{0, 1, 0, -1}[dir]; }
    static void count() { if (++moves > 200) throw new RuntimeException("more than 200 moves: infinite loop?"); }

    /** Drive forward one square. Crashes if a wall or the field edge is in the way. */
    static void forward() {
        count();
        if (isWall(aheadX(), aheadY())) throw new RuntimeException("CRASH at (" + x + "," + y + ")");
        x = aheadX(); y = aheadY();
    }
    static void turnLeft()  { count(); dir = (dir + 3) % 4; }
    static void turnRight() { count(); dir = (dir + 1) % 4; }
    /** True if the square ahead is free. The ball counts as blocking until you pick it up. */
    static boolean pathClear() {
        boolean ballAhead = !hasBall && aheadX() == ballX && aheadY() == ballY;
        return !isWall(aheadX(), aheadY()) && !ballAhead;
    }
    /** True if the robot is on the ball's square (and hasn't picked it up yet). */
    static boolean onBall() { return !hasBall && x == ballX && y == ballY; }
    static boolean atGoal() { return x == 8 && y == 0; }
    static void pickUp() {
        count();
        if (!onBall()) throw new RuntimeException("pickUp(): no ball at (" + x + "," + y + ")");
        hasBall = true;
    }
    static void score() {
        count();
        if (!hasBall) throw new RuntimeException("score(): no ball");
        if (!atGoal()) throw new RuntimeException("score(): not at the goal");
        scored = true;
    }

    public static void main(String[] args) {
        for (int[] spot : SPOTS) {
            x = 0; y = 4; dir = 0; moves = 0; hasBall = false; scored = false;
            ballX = spot[0]; ballY = spot[1];
            String result;
            try {
                autonomous();
                result = scored ? "SCORED!" : "finished, but didn't score";
            } catch (RuntimeException e) {
                result = e.getMessage();
            }
            System.out.println("Ball at (" + ballX + "," + ballY + "): " + result + "  [" + moves + " moves]");
        }
    }
}

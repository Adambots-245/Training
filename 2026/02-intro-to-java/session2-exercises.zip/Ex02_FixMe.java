// Exercise 2: Fix me!
// This file has FIVE mistakes, one of each kind from the slides:
//   a missing semicolon, a missing brace, a wrong capital letter,
//   curly "smart" quotes, and a class name that doesn't match the file name.
// Fix them one at a time. Read the FIRST error message, fix it, run again.
// When it works, it prints three lines.

public class Ex02_Fixme {
    public static void main(String[] args) {
        int team = 245
        string name = "AdamBots";
        system.out.println("Team " + team);
        System.out.println(name);
        System.out.println(“Fixed it!”);

}

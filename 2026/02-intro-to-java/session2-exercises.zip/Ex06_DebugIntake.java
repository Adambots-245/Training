// Exercise 6: Debug the intake (work in pairs)
// SIX bugs, one from each section of today's deck:
//   structure, types, operators, comparisons, loops, methods.
// Step 1: fix the compile errors (read the FIRST error, fix, run again).
// Step 2: once it runs, compare the output to the expected output below
//         and fix what is still wrong. If it freezes, press Stop (red square).
//
// Expected output when everything is fixed:
//   Loop 0: hasGamePiece=false  motor=0.375    <- gentle start: half speed
//   Loop 1: hasGamePiece=false  motor=0.375
//   Loop 2: hasGamePiece=false  motor=0.75
//   Loop 3: hasGamePiece=false  motor=0.75
//   Loop 4: hasGamePiece=false  motor=0.75
//   Loop 5: hasGamePiece=true  motor=0.0       <- piece arrives: stop
//   Loop 6: hasGamePiece=true  motor=0.0
//   Loop 7: hasGamePiece=true  motor=0.0

public class Ex06_DebugIntake {

    // ----- pretend robot hardware (no WPILib needed; don't change this part) -----
    static class Motor {
        double throttle;
        void setThrottle(double t) { throttle = t; }
    }
    static class BeamBreak {
        int time;
        // true = beam NOT blocked. A game piece arrives at loop 5 and blocks it.
        boolean get() { return time < 5; }
    }
    static final Motor motor = new Motor();
    static final BeamBreak beamBreak = new BeamBreak();
    static int loopsRunning = 0;

    static final int kIntakeSpeed = 0.75;

    // Returns true when a game piece is inside (beam blocked).
    static boolean hasGamePiece() {
        boolean blocked = !beamBreak.get();
    }

    static void run() {
        if (hasGamePiece() = true) {
            motor.setThrottle(0.0);
        } else {
            double speed = kIntakeSpeed;
            if (loopsRunning < 2) {
                speed = kIntakeSpeed * (1 / 2);   // gentle start at half speed
            }
            motor.setThrottle(speed);
            loopsRunning++;
        }
    }

    // Called by the robot loop every 20 ms.
    static void periodic() {
        // wait for the game piece to arrive
        while (!hasGamePiece()) { }
        run();


    // ----- the robot loop: calls periodic() 8 times, like 8 x 20 ms -----
    public static void main(String[] args) {
        for (int loop = 0; loop < 8; loop++) {
            beamBreak.time = loop;
            periodic();
            System.out.println("Loop " + loop + ": hasGamePiece=" + hasGamePiece() + "  motor=" + motor.throttle);
        }
    }
}

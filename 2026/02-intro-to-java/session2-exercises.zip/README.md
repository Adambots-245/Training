# Session 2 exercise pack: Intro to Java

Copy these files into **`C:\bootcamp`** (make the folder in File Explorer under This PC → Local Disk (C:)). Don't use Documents, Desktop or anything in OneDrive: OneDrive syncing breaks WPILib builds. Mac: use a `bootcamp` folder in your home folder.

Then open `C:\bootcamp` in **WPILib 2027 VS Code** (it includes Java 25) with File → Open Folder. Open any file and click **Run** above `main`.

| File | Slide | What you practice |
|---|---|---|
| `Ex01_Hello.java` | Try it: first program | Run a program, change the output |
| `Ex02_FixMe.java` | Try it: spot the bug | Fix five classic compiler errors (it won't run until you do) |
| `Ex03_Predict.java` | Try it: predict | Check your predictions about types and operators |
| `Ex04_Countdown.java` | Try it: loops and decisions | for loop + if |
| `Ex04b_GameStretch.java` | Stretch | Our first session's Level 2 game, written in real Java |
| `Ex05_Methods.java` | Try it: write two methods | Write and call methods (prints PASS/FAIL) |
| `Ex06_DebugIntake.java` | Try it: debug the robot code | Find six planted bugs in robot-style code |
| `CheatSheet.pdf` | | One-page reference |

Tips: fix the **first** error first; format with Shift+Alt+F (Windows) or Shift+Option+F (Mac); if a program freezes, press the red Stop square.

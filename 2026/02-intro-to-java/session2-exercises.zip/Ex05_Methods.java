// Exercise 5: Write two methods
// 1. isFast: return true if speed is MORE than 0.7, otherwise false.
// 2. average: return the average of a and b.
// Then run it. Every check should say PASS.
// Stretch: write clamp(value, max): returns value, but never more than max.

public class Ex05_Methods {

    static boolean isFast(double speed) {
        // TODO
        return false;
    }

    static double average(double a, double b) {
        // TODO
        return 0.0;
    }

    // Stretch: uncomment and finish clamp, then uncomment its checks in main
    // static double clamp(double value, double max) {
    //     // TODO
    // }

    public static void main(String[] args) {
        check("isFast(0.9) is true", isFast(0.9) == true);
        check("isFast(0.5) is false", isFast(0.5) == false);
        check("isFast(0.7) is false", isFast(0.7) == false);
        check("average(2, 4) is 3.0", average(2, 4) == 3.0);
        check("average(1, 2) is 1.5", average(1, 2) == 1.5);
        // check("clamp(1.4, 1.0) is 1.0", clamp(1.4, 1.0) == 1.0);
        // check("clamp(0.3, 1.0) is 0.3", clamp(0.3, 1.0) == 0.3);
    }

    static void check(String what, boolean ok) {
        System.out.println((ok ? "PASS  " : "FAIL  ") + what);
    }
}

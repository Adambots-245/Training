// Exercise 3: Predict the output
// Write down your prediction for each line FIRST, then run the program.
// Were you right? Ask about any surprise.

public class Ex03_Predict {
    public static void main(String[] args) {
        System.out.println("1.  7 / 2         = " + (7 / 2));
        System.out.println("2.  \"2\" + 2       = " + ("2" + 2));
        System.out.println("3.  2 + 2 + \"2\"   = " + (2 + 2 + "2"));
        System.out.println("4.  10 % 3        = " + (10 % 3));
        System.out.println("5.  5 == 5.0      = " + (5 == 5.0));
        System.out.println("6.  !(3 > 2)      = " + (!(3 > 2)));

        // Bonus round
        System.out.println("7.  1 / 2         = " + (1 / 2));
        System.out.println("8.  1.0 / 2       = " + (1.0 / 2));
        System.out.println("9.  0.1 + 0.2     = " + (0.1 + 0.2));
        System.out.println("10. 2 + 3 * 4     = " + (2 + 3 * 4));
        System.out.println("11. \"Team \" + 2 + 4 + 5 = " + ("Team " + 2 + 4 + 5));

        int x = 5;
        x = x + 1;
        System.out.println("12. x after x = x + 1 is " + x);
    }
}

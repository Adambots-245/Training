// Exercise 4: Match countdown
// 1. Use a for loop to print the numbers 10 down to 1.
// 2. Inside the loop, when the number is 3 or less, ALSO print "Get ready!"
// 3. After the loop, print "Match start!"
//
// Hint: count down by starting at 10, looping while i >= 1, and using i--
//
// Stretch: open Ex04b_GameStretch.java and rewrite our first session's Level 2 game in Java.

public class Ex04_Countdown {
    public static void main(String[] args) {
        // TODO: write your for loop here

        System.out.println("Match start!");
    }
}

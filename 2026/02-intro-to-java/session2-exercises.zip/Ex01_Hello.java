// Exercise 1: Hello, World
// 1. Click "Run" above main (VS Code) and check the output at the bottom.
// 2. Change the message to say hello to YOU.
// 3. Add two more println lines: your grade, and your favorite robot part.

public class Ex01_Hello {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
